package conf

const MySQLDSN = "root:local_mysql_test@tcp(localhost:3306)/test?charset=utf8mb4&parseTime=True"

const SQLiteDBName = "gen_sqlite.db"
