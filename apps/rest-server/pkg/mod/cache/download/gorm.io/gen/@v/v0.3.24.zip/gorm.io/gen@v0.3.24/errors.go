package gen

import "errors"

var (
	// ErrEmptyCondition empty condition
	ErrEmptyCondition = errors.New("empty condition")
)
