# Swagger 2.0

Visit https://github.com/iris-contrib/swagger instead.
