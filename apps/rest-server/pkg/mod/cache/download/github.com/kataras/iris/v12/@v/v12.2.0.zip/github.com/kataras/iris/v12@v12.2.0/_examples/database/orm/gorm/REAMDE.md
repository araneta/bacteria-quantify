# GORM

This example is pull by [#1275 PR](https://github.com/kataras/iris/pull/1275) by [@wuxiaoxiaoshen](https://github.com/wuxiaoxiaoshen).

A more complete and real-world example can be found at the <https://github.com/snowlyg/IrisApiProject> project created by [@snowlyg](https://github.com/snowlyg).
