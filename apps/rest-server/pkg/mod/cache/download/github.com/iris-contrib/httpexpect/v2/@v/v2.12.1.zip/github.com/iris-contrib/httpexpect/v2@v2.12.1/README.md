# HTTP Expect

Test functionality behind [iris/httptest](https://github.com/kataras/iris/tree/master/_examples/testing/httptest) forked by [gavv/httpexpect](https://github.com/gavv/httpexpect).