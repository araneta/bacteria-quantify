# Test [![GoDoc](http://godoc.org/github.com/tdewolff/test?status.svg)](http://godoc.org/github.com/tdewolff/test)

Test is a helper package written in [Go][1]. It implements a few functions that are useful for io testing, such as readers and writers that fail after N consecutive reads/writes.

## License
Released under the [MIT license](LICENSE.md).

[1]: http://golang.org/ "Go Language"
